package com.origamisoftware.teach.advanced.xml;

/**
 * This is a maker interface which indicates implementers are DAO classes.
 */
public interface DatabasesAccessObject{

}
