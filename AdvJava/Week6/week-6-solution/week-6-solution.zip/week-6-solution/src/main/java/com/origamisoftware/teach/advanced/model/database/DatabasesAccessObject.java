package com.origamisoftware.teach.advanced.model.database;

/**
 * This is a maker interface which indicates implementers are DAO classes.
 */
public interface DatabasesAccessObject{

}
