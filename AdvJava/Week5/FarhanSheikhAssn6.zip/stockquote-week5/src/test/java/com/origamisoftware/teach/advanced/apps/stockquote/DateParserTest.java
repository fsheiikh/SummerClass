/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.origamisoftware.teach.advanced.apps.stockquote;

import java.util.Calendar;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *Unit Test for the DatePArser Class
 * @author Farhan Sheikh
 */
public class DateParserTest {
    
    /**
     * Positive Test of getDateParsed method, of class DateParser.
     */
    @Test
    public void testGetDateParsedPositive() {
        String dateInString = "2001-01-01";
        Calendar result = DateParser.getDateParsed(dateInString);
        assertNotNull("A valid date returns a valid Calender Object", result);
    }
    
    /**
     * Negative Test of getDateParsed method, of class DateParser.
     * Pass in a string thats not a vlid date
     */
    @Test(expected = java.lang.AssertionError.class)
    public void testGetDateParsedNegative() {
        String dateInString = "2";
        Calendar result = DateParser.getDateParsed(dateInString);
        assertNull("An invalid date is caught", result);
    }
    
}
