package com.origamisoftware.teach.advanced.util;

import com.ibatis.common.jdbc.ScriptRunner;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * A class that contains database related utility methods.
 */
public class DatabaseUtils {

    // in a real program these values would be a configurable property and not hard coded.
    // JDBC driver name and database URL
    //private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    //private static final String DB_URL = "jdbc:mysql://localhost:8889/stocks";

    private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    private static final String DB_URL = "jdbc:mysql://localhost:8889/stocks";
    //  Database credentials
    private static final String USER = "root";
    private static final String PASS = "root";
    

    //The following three fields are the orginal credentials from the code and are executed if the above do not work
    private static final String DB_URL2 = "jdbc:mysql://localhost:3306/stocks";
    private static final String USER2 = "monty";
    private static final String PASS2 = "some_pass";
    
    /**
     * A method that connects to the database based on the fields denoted above
     */
    public static Connection getConnection() throws DatabaseConnectionException{
        Connection connection = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection =   DriverManager.getConnection(DB_URL, USER, PASS);
            //if(connection.)
            
            
        } catch (ClassNotFoundException  | SQLException e)  {
           //try to connect with the original credentials from the code
             try {
                Class.forName("com.mysql.jdbc.Driver");
                connection =   DriverManager.getConnection(DB_URL2, USER, PASS);
                System.out.println("WE ARE CONNECTED");
            
            } catch (ClassNotFoundException  | SQLException e2)  {
                throw new  DatabaseConnectionException("Could not connection to database." + e2.getMessage(), e2);
            }
        }
        return connection;
    }

    /**
     * A utility method that runs a db initialize script.
     * @param initializationScript    full path to the script to run to create the schema
     * @throws DatabaseInitializationException
     */
    public static void initializeDatabase(String initializationScript) throws DatabaseInitializationException {

        Connection connection = null;
        try {
            connection = getConnection();
            ScriptRunner runner = new ScriptRunner(connection, false, false);
            InputStream inputStream = new  FileInputStream(initializationScript);

            InputStreamReader reader = new InputStreamReader(inputStream);

            runner.runScript(reader);
            reader.close();
            connection.commit();
            connection.close();

        } catch (DatabaseConnectionException | SQLException |IOException e) {
           throw new DatabaseInitializationException("Could not initialize db because of:"
                   + e.getMessage(),e);
        }


    }
}
