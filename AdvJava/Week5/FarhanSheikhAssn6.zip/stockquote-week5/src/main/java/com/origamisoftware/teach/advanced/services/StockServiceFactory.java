package com.origamisoftware.teach.advanced.services;

import com.origamisoftware.teach.advanced.model.StockQuote;
import com.origamisoftware.teach.advanced.util.DatabaseConnectionException;
import com.origamisoftware.teach.advanced.util.DatabaseUtils;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * A factory that returns a <CODE>StockService</CODE> instance.
 */
public class StockServiceFactory {

    /**
     * Prevent instantiations
     */
    private StockServiceFactory() {}

    /**
     *
     * @return get a <CODE>StockService</CODE> instance
     */
    public static StockService getInstance() {
        return new DatabaseStockService() {
            @Override
            public StockQuote getQuote(String symbol) throws StockServiceException {
               // todo - this is a pretty lame implementation why? - it just returns the first stock it gets. We need a useful method that gives us a stock of perhpas today
                StockQuote stockQuote = null;
        
                //code from stackOverflow to get the right date format for today (We dont need the following few lines of code unless we implement a date restriction(only getting stocks form today))
                Calendar calender = Calendar.getInstance();
                SimpleDateFormat sqlFormat = new SimpleDateFormat("yyyy-MM-dd");
                String formattedDate = sqlFormat.format(calender.getTime());
                //System.out.println(formatted); // Output format : "2012-09-26"
            
                try {
                    Connection connection = DatabaseUtils.getConnection();
                    Statement statement = connection.createStatement();
                    String queryString = "select * from quotes where symbol = '" + symbol + "' " + 
                                         //"and CAST(time AS DATE) = '" + formattedDate + "' " + 
                                         "order by time desc limit 1";

                    ResultSet resultSet = statement.executeQuery(queryString);

                    while(resultSet.next()) { 
                        String symbolValue = resultSet.getString("symbol");
                        java.sql.Date time = resultSet.getDate("time");
                        BigDecimal price = resultSet.getBigDecimal("price");
                        stockQuote = new StockQuote(price, time, symbolValue);
                        //System.out.println("In DBStockService:" + stockQuote);     
                    }

                } catch (DatabaseConnectionException | SQLException exception) {
                    throw new StockServiceException(exception.getMessage(), exception);
                }
                if (stockQuote ==  null) {
                    throw new StockServiceException("There is no stock data for:" + symbol);
                }

                return stockQuote;
            }
            
            /**
            *
            * @return get a StockService List 
            */
            @Override
            public List<StockQuote> getQuote(String symbol, Calendar from, Calendar until) throws StockServiceException {

                SimpleDateFormat sqlFormat = new SimpleDateFormat("yyyy-MM-dd");
                String formattedDateFrom = sqlFormat.format(from.getTime());
                String formattedDateUntil = sqlFormat.format(until.getTime());
                System.out.println("from " + formattedDateFrom + " unitl " + formattedDateUntil);

                List<StockQuote> stockQuotes = null;

                try {
                    Connection connection = DatabaseUtils.getConnection();
                    Statement statement = connection.createStatement();
                    String queryString = "select * from quotes where symbol = '" + symbol + "' " + 
                                         "and CAST(time AS DATE) > '" + formattedDateFrom + "' " + 
                                         "and CAST(time AS DATE) < '" + formattedDateUntil + "' " + 
                                         "order by time asc";

                    ResultSet resultSet = statement.executeQuery(queryString);
                    stockQuotes = new ArrayList<>(resultSet.getFetchSize());
                    while(resultSet.next()) {
                        String symbolValue = resultSet.getString("symbol");
                        java.sql.Date time = resultSet.getDate("time");
                        BigDecimal price = resultSet.getBigDecimal("price");
                        stockQuotes.add(new StockQuote(price, time, symbolValue));
                    }

                } catch (DatabaseConnectionException | SQLException exception) {
                    throw new StockServiceException(exception.getMessage(), exception);
                }
                if (stockQuotes.isEmpty()) {
                    throw new StockServiceException("There is no stock data for:" + symbol);
                }
                return stockQuotes;
            }
        };
    }

}
