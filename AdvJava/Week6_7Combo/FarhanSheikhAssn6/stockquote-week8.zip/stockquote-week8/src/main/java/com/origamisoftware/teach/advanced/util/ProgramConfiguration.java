package com.origamisoftware.teach.advanced.util;

import java.util.Properties;

/**
 *  A Utility class that provides application properties and
 *  configuration settings.
 */
public class ProgramConfiguration {

    public static Properties getApplicationProperties() {
      return null;
    }

}
