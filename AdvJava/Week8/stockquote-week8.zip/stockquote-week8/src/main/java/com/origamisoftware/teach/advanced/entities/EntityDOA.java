package com.origamisoftware.teach.advanced.entities;

/**
 * This is a maker interface which indicates implementers are DAO classes.
 */
public interface EntityDOA{

}
